$(document).ready(function() {
    $(".login-area").hover(function() {
        $(".config").addClass("bk-dark");
        $(".area-ntf-login").css("display", "flex");

    }, function() {
        $(".config").removeClass("bk-dark");
        $(".area-ntf-login").css("display", "none");

    });

    /* Slide */

    $("#slide figure img:eq(0)").show().addClass("ativo")

    function Cslide() {
        if ($(".ativo").next().length) {
            $(".ativo").fadeOut().removeClass("ativo").next().fadeIn().addClass("ativo");
        } else {
            $(".ativo").fadeOut().removeClass("ativo")
            $("#slide figure img:eq(0)").fadeIn().addClass("ativo");
        };
    };

    setInterval(Cslide, 5000);

    $("#avancar").click(Cslide);

    $("#voltar").click(function() {
        if ($(".ativo").attr("alt") != "Legenda 01") {
            $(".ativo").fadeOut().removeClass("ativo").prev().fadeIn().addClass("ativo");
        } else {
            $(".ativo").fadeOut().removeClass("ativo")
            $("#slide figure img:eq(3)").fadeIn().addClass("ativo");
        };
    });


});