$(document).ready(function() {

    $("#exp").click(function() {
        $("#exp").toggleClass("opc");

        if ($("#exp").attr("class") === "opc") {
            if ($("#exp-ft").attr("class") === "opc") {
                $(".a").css("display", "flex");
            } else {
                $(".sumiu").css("display", "none");
            }
        } else if ($("#exp-ft").attr("class") === "opc") {
            $(".sumiu-ft").css("display", "none");
        } else {
            $(".sumiu").css("display", "flex");
        }
    });


    $("#exp-ft").click(function() {
        $("#exp-ft").toggleClass("opc");

        if ($("#exp-ft").attr("class") === "opc") {
            if ($("#exp").attr("class") === "opc") {
                $(".a").css("display", "flex");
            } else {
                $(".sumiu-ft").css("display", "none");
            }
        } else if ($("#exp").attr("class") === "opc") {
            $(".sumiu").css("display", "none");
        } else {
            $(".sumiu-ft").css("display", "flex");

        }

    });

});